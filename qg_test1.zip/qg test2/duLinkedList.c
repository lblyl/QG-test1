#include "duLinkedList.h"
#include <stdio.h>
#include <malloc.h>

/**
 *  @name        : Status InitList_DuL(DuLinkedList *L)
 *	@description : initialize an empty linked list with only the head node
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList_DuL(DuLinkedList *L) {
	DuLinkedList p1,p2;
	int i,n;
	printf("����������Ҫ�������������ȣ�");
	scanf("%d", &n);
    (*L) = (DuLinkedList)malloc(sizeof(DuLNode));	//head pointer
	p1 = p2 =(*L);
	(*L)->data = 0;
    for(i=1;i<n;i++){
    	p1 = (DuLinkedList)malloc(sizeof(DuLNode));
 	 	p1->data = i; 
		p2->next = p1; 
		p1->prior = p2;
		p2 = p1;
	} 
	p1->next = NULL;
	printf("the list have been created\n");
	return SUCCESS;
}

/**
 *  @name        : void DestroyList_DuL(DuLinkedList *L)
 *	@description : destroy a linked list
 *	@param		 : L(the head node)
 *	@return		 : status
 *  @notice      : None
 */
void DestroyList_DuL(DuLinkedList *L) {
	DuLinkedList p1,p2;
	p2 = p1 = (*L);
		if((*L)!=NULL){
			while(p1 != NULL){
				p1 = p1->next;
				free(p2);
				p2 = p1;
			}
			(*L) = NULL;	
			printf("success to destroy\n");			
		}
		else
			printf("ERROR\n");
}

/**
 *  @name        : Status InsertBeforeList_DuL(DuDuLNode *p, LNode *q)
 *	@description : insert node q before node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertBeforeList_DuL(DuLNode *p, DuLNode *q) {
	DuLNode *bef_to_p;
	int num;
	q = (DuLNode *)malloc(sizeof(DuLNode));
	printf("the data you want to add:");
	scanf("%d",&q->data);
	printf("NO.? the p is:");
	scanf("%d",&num);
	for(num;num>0;num--){
		p = p->next;
	}
	bef_to_p = p->prior;
	p->prior = q;
	q->prior = bef_to_p;
	return SUCCESS;
}

/**
 *  @name        : Status InsertAfterList_DuL(DuLNode *p, DuLNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertAfterList_DuL(DuLNode *p, DuLNode *q) {
	DuLNode *nx_to_p;
	int num;
	q = (DuLNode *)malloc(sizeof(DuLNode));
	printf("the data you want to add:");
	scanf("%d",&q->data);
	printf("NO.? the p is:");
	scanf("%d",&num);
	for(num;num>0;num--){
		p = p->next;
	}
	nx_to_p = p->next;			//make the list frequently
	p->next = q;
	q->next = nx_to_p; 
	return SUCCESS;
}

/**
 *  @name        : Status DeleteList_DuL(DuLNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : status
 *  @notice      : None
 */
Status DeleteList_DuL(DuLNode *p, ElemType *e) {
	DuLNode *w_del;
	int num;
	printf("NO.? the p is:");
	scanf("%d",&num);
	for(num;num>0;num--){
		p = p->next;
	}
	w_del = p->next;
	p->next = p->next->next;
	
	*e = w_del->data; 
	free(w_del);
	printf("the elemtype %d has been delete\n", *e);
	return SUCCESS;
}

/**
 *  @name        : void TraverseList_DuL(DuLinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit
 *	@return		 : Status
 *  @notice      : None
 */
void TraverseList_DuL(DuLinkedList L/*, void (*visit)(ElemType e)*/) {
	DuLinkedList p1;
	p1 = L;
	if(p1==NULL) {
		printf("there is no data \n");
	}
	while(p1!=NULL){
		printf("%d\n", p1->data);
		p1 = p1->next;
	}	
}
