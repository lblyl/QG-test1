#include "duLinkedList.h"
#include <stdio.h>
#include <malloc.h>

int main(){
	printf("*****************************************************\n");
	printf("1.initlist\n");
	printf("2.destory list\n");
	printf("3.InsertAfterList \n");
	printf("4.InsertBeforeList \n");
	printf("5.DeleteList\n");
	printf("6.travellist\n");
	printf("*****************************************************\n");
	int choice;
	DuLinkedList L;
	scanf("%d", &choice);
	switch(choice){
		case 1:{
			InitList_DuL(&L);
			break;
		}
		case 2:{
			DestroyList_DuL(&L);
			break;
		} 
		case 3:{
			DuLNode *q,*p = L;
			q = NULL;
			InsertAfterList_DuL(p, q);
			break;
		}
		case 4:{
			DuLNode *q,*p = L;
			q = NULL;
			InsertBeforeList_DuL(p, q); 
			break;
		}
		case 5:{
			DuLNode *p = L;
			ElemType e;
			DeleteList(p, &e);
			break;
		}
		case 6:{
			TraverseList(L);
			break;
		}
		default:printf("something wrong!\n");break;
	}
}

